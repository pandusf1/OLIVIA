<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PartnerNearbyController extends Controller
{
    //
}
