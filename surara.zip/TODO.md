# TODO - Fitur: Map Partner Terdekat, CRUD Partner Admin, Chat, Psikolog/Pengacara + Price List + Pembayaran Bohongan

## Rencana Implementasi

### Tahap 1 — Database & Model
- [ ] Migration: tambah kolom `latitude` dan `longitude` di `partners`
- [ ] Migration: buat tabel `user_locations` untuk menyimpan GPS user (lat/lng)
- [ ] Migration: buat tabel `price_lists` (partner_id, service_name, price, duration opsional)
- [ ] Migration: buat tabel `chat_threads` (user_id, partner_id)
- [ ] Migration: buat tabel `chat_messages` (thread_id, sender, message)
- [ ] Buat/ubah model: `PriceList`, `UserLocation`, `ChatThread`, `ChatMessage` dan relasi di `Partner`

### Tahap 2 — Backend Controller & Route
- [ ] Route + controller: simpan lokasi user dari dashboard (`POST /dashboard/lokasi/simpan`)
- [ ] Route + controller: ambil partner terdekat (`GET /dashboard/partners-terdekat`)
- [ ] Route + controller: daftar psikolog/pengacara terdekat + detail + price list
- [ ] Route + controller: halaman pembayaran bohong (mock)
- [ ] Route + controller: chat thread (buka chat, kirim pesan, tampilkan riwayat)

### Tahap 3 — UI/Blade
- [ ] Update `resources/views/dashboard.blade.php`:
  - [ ] Tambah map partner terdekat + marker & klik detail
  - [ ] Tambah section daftar psikolog terdekat dan pengacara terdekat
- [ ] Buat view: detail psikolog/pengacara + price list + tombol pilih harga
- [ ] Buat view: pembayaran bohong
- [ ] Buat view: halaman chat (tampilkan history)

### Tahap 4 — Admin CRUD Partner
- [ ] Tambah route + method: edit/update/destroy di `AdminPartnerController`
- [ ] Buat view: `resources/views/pages/admin/partners/edit.blade.php`
- [ ] Update view list partner admin agar ada tombol edit & hapus
- [ ] Samakan style UI edit/hapus dengan style dashboard admin yang ada

### Tahap 5 — Testing
- [ ] Jalankan migration
- [ ] Jalankan validasi fitur map (GPS tersimpan, marker tampil)
- [ ] Jalankan validasi flow psikolog/pengacara → price list → pembayaran bohong → chat
- [ ] Jalankan validasi admin CRUD partner

