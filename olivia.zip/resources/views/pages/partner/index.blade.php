<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Safora - Dashboard Mitra</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-gray-50 text-gray-900 antialiased">
@php
    $backUrl = null;
    $showBrand = true;
    $categoryClass = [
        'kekerasan' => 'bg-red-100 text-red-800 border-red-200',
        'salah tangkap' => 'bg-blue-100 text-blue-800 border-blue-200',
        'pelecehan' => 'bg-yellow-100 text-yellow-900 border-yellow-200',
        'kecelakaan' => 'bg-green-100 text-green-800 border-green-200',
    ];
@endphp
@include('partials.nav-auth')

<main class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
    @if(session('success'))
        <div class="mb-5 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm font-medium text-green-800">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-800">{{ session('error') }}</div>
    @endif

    <header class="mb-8 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
            <div class="mb-3 flex flex-wrap items-center gap-2">
                <span class="rounded-full border border-green-200 bg-green-50 px-3 py-1 text-xs font-bold text-green-700">Mitra Terverifikasi</span>
                <span class="rounded-full border border-gray-200 bg-white px-3 py-1 text-xs font-semibold text-gray-600">{{ $partner->partner_type }}</span>
            </div>
            <h1 class="text-3xl font-black tracking-tight text-gray-950">{{ $partner->partner_name }}</h1>
            <p class="mt-1 text-sm text-gray-500">{{ $partner->city }} - dashboard respons laporan darurat Safora</p>
        </div>

        <div class="grid grid-cols-3 gap-3">
            <div class="rounded-lg border border-gray-200 bg-white p-4">
                <p class="text-xs font-semibold uppercase text-gray-500">Menunggu Respons</p>
                <p class="mt-2 text-2xl font-black text-red-700">{{ $stats['pending'] }}</p>
            </div>
            <div class="rounded-lg border border-gray-200 bg-white p-4">
                <p class="text-xs font-semibold uppercase text-gray-500">Sedang Ditangani</p>
                <p class="mt-2 text-2xl font-black text-orange-600">{{ $stats['progress'] }}</p>
            </div>
            <div class="rounded-lg border border-gray-200 bg-white p-4">
                <p class="text-xs font-semibold uppercase text-gray-500">Selesai Bulan Ini</p>
                <p class="mt-2 text-2xl font-black text-green-700">{{ $stats['resolved_month'] }}</p>
            </div>
        </div>
    </header>

    <section class="mb-8">
        <div class="mb-4 flex items-center justify-between">
            <div>
                <h2 class="text-xl font-black text-gray-950">Laporan Masuk</h2>
                <p class="text-sm text-gray-500">Pending dan belum melewati batas respons.</p>
            </div>
        </div>

        @if($pendingRoutings->count() > 0)
            <div class="grid gap-4 lg:grid-cols-2">
                @foreach($pendingRoutings as $routing)
                    @php
                        $report = $routing->report;
                        $catKey = strtolower($report->category);
                        $badgeClass = $categoryClass[$catKey] ?? 'bg-gray-100 text-gray-700 border-gray-200';
                    @endphp
                    <article class="rounded-lg border border-gray-200 bg-white p-5 shadow-sm">
                        <div class="mb-4 flex flex-wrap items-start justify-between gap-3">
                            <div class="flex flex-wrap items-center gap-2">
                                <span class="rounded-full border px-3 py-1 text-xs font-bold {{ $badgeClass }}">{{ $report->category }}</span>
                                @if($report->anonymous)
                                    <span class="rounded-full bg-purple-50 px-3 py-1 text-xs font-bold text-purple-700">Anonim</span>
                                @endif
                                @if($report->evidences_count > 0)
                                    <span class="rounded-full bg-gray-100 px-3 py-1 text-xs font-bold text-gray-700">{{ $report->evidences_count }} Bukti</span>
                                @endif
                            </div>
                            <div class="text-right">
                                <p class="text-xs font-bold uppercase text-red-700">Menunggu Respons</p>
                                <p class="countdown text-sm font-black text-gray-950" data-expires-at="{{ optional($routing->expires_at)->toIso8601String() }}">--:--</p>
                            </div>
                        </div>

                        <p class="mb-4 text-sm leading-6 text-gray-700">{{ \Illuminate\Support\Str::limit($report->description ?: 'Tidak ada deskripsi tambahan.', 100) }}</p>

                        <div class="mb-5 grid gap-2 text-sm text-gray-500">
                            <p><span class="font-semibold text-gray-700">Lokasi:</span> {{ $report->location_text ?: ($report->latitude ? $report->latitude . ', ' . $report->longitude : 'Tidak tersedia') }}</p>
                            <p><span class="font-semibold text-gray-700">Waktu masuk:</span> {{ $report->created_at->format('d M Y, H:i') }}</p>
                        </div>

                        <form method="POST" action="{{ route('partner.report.accept', $report->id) }}">
                            @csrf
                            <button type="submit" class="w-full rounded-lg bg-gray-950 px-5 py-3 text-sm font-black text-white transition hover:bg-gray-800">
                                Terima & Mulai Chat
                            </button>
                        </form>
                    </article>
                @endforeach
            </div>
        @else
            <div class="rounded-lg border border-dashed border-gray-300 bg-white px-6 py-12 text-center">
                <p class="text-lg font-bold text-gray-700">Tidak ada laporan menunggu saat ini</p>
                <p class="mt-1 text-sm text-gray-500">Laporan baru akan muncul di sini selama masih dalam batas respons.</p>
            </div>
        @endif
    </section>

    <section class="mb-8">
        <h2 class="mb-4 text-xl font-black text-gray-950">Sedang Ditangani</h2>
        <div class="overflow-hidden rounded-lg border border-gray-200 bg-white">
            @forelse($activeReports as $report)
                @php $acceptedAt = optional($report->partnerRoutings->first()?->responded_at)->format('d M Y, H:i'); @endphp
                <div class="flex flex-col gap-3 border-b border-gray-100 p-4 last:border-b-0 md:flex-row md:items-center md:justify-between">
                    <div>
                        <div class="flex flex-wrap items-center gap-2">
                            <p class="font-bold text-gray-950">{{ $report->category }}</p>
                            <span class="text-xs font-semibold text-gray-500">{{ $acceptedAt ?: 'Waktu diterima belum tercatat' }}</span>
                        </div>
                        <p class="mt-1 text-sm text-gray-500">{{ $report->anonymous ? 'Anonim' : ($report->user?->name ?? 'Pelapor') }}</p>
                    </div>
                    <div class="flex flex-col gap-2 sm:flex-row">
                        <a href="/chat/messages/{{ auth()->user()->partner_id }}?report_id={{ $report->id }}" class="rounded-lg border border-gray-300 px-4 py-2 text-center text-sm font-bold text-gray-800 transition hover:border-gray-500">Lanjut Chat</a>
                        <form method="POST" action="{{ route('partner.status', $report->id) }}">
                            @csrf
                            <input type="hidden" name="status" value="Resolved">
                            <button type="submit" class="w-full rounded-lg bg-green-700 px-4 py-2 text-sm font-bold text-white transition hover:bg-green-800">Tandai Selesai</button>
                        </form>
                    </div>
                </div>
            @empty
                <div class="px-6 py-8 text-center text-sm text-gray-500">Belum ada laporan yang sedang ditangani.</div>
            @endforelse
        </div>
    </section>

    <section>
        <details class="rounded-lg border border-gray-200 bg-white">
            <summary class="cursor-pointer px-5 py-4 text-lg font-black text-gray-950">Riwayat Selesai Bulan Ini</summary>
            <div class="border-t border-gray-100">
                @forelse($resolvedReports as $report)
                    <div class="flex flex-col gap-2 border-b border-gray-100 px-5 py-4 last:border-b-0 md:flex-row md:items-center md:justify-between">
                        <div>
                            <p class="font-bold text-gray-900">{{ $report->category }}</p>
                            <p class="text-sm text-gray-500">{{ $report->anonymous ? 'Anonim' : ($report->user?->name ?? 'Pelapor') }} - selesai {{ $report->updated_at->format('d M Y, H:i') }}</p>
                        </div>
                        <a href="{{ route('partner.show', $report->id) }}" class="text-sm font-bold text-gray-700 underline">Lihat Detail</a>
                    </div>
                @empty
                    <div class="px-5 py-8 text-center text-sm text-gray-500">Belum ada laporan selesai bulan ini.</div>
                @endforelse
            </div>
        </details>
    </section>
</main>

<script>
    function updateCountdowns() {
        document.querySelectorAll('.countdown').forEach(function (node) {
            const raw = node.dataset.expiresAt;
            if (!raw) {
                node.textContent = 'Tanpa batas';
                return;
            }

            const diff = new Date(raw).getTime() - Date.now();
            if (diff <= 0) {
                node.textContent = 'Expired';
                node.closest('article')?.classList.add('opacity-60');
                return;
            }

            const totalSeconds = Math.floor(diff / 1000);
            const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
            const seconds = String(totalSeconds % 60).padStart(2, '0');
            node.textContent = minutes + ':' + seconds;
        });
    }

    updateCountdowns();
    setInterval(updateCountdowns, 1000);
</script>
</body>
</html>
