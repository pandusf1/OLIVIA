<?php

namespace App\Console\Commands;

use App\Models\AuditLog;
use App\Models\ReportPartnerRouting;
use Illuminate\Console\Command;

class ExpireReportRoutings extends Command
{
    protected $signature = 'reports:expire-routings';

    protected $description = 'Menandai routing laporan partner yang melewati batas respons sebagai expired.';

    public function handle(): int
    {
        $expiredRoutings = ReportPartnerRouting::query()
            ->where('status', 'pending')
            ->whereNotNull('expires_at')
            ->where('expires_at', '<', now())
            ->get();

        foreach ($expiredRoutings as $routing) {
            $routing->update(['status' => 'expired']);

            try {
                AuditLog::log('expire_report_routing', 'report', $routing->report_id);
            } catch (\Exception $e) {
                // Audit tidak boleh menggagalkan scheduler.
            }
        }

        $this->info($expiredRoutings->count() . ' routing laporan ditandai expired.');

        return self::SUCCESS;
    }
}
