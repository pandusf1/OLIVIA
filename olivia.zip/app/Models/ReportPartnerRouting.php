<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class ReportPartnerRouting extends Model
{
    use HasUuids;

    protected $table = 'report_partner_routings';

    protected $fillable = [
        'report_id',
        'partner_id',
        'status',
        'routed_at',
        'responded_at',
        'expires_at',
    ];

    public $incrementing = false;
    protected $keyType = 'string';

    protected $casts = [
        'routed_at' => 'datetime',
        'responded_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function report()
    {
        return $this->belongsTo(Report::class);
    }

    public function partner()
    {
        return $this->belongsTo(Partner::class);
    }
}
